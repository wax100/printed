<?php
require MODX_CORE_PATH . 'components/pdotools/model/pdotools/pdotools.class.php';