--------------------
lmims
--------------------
Author: Kartashov Alexey <ya.antixrist@gmail.com>
--------------------

"<b>L</b>ast <b>M</b>odified", "<b>I</b>f <b>M</b>odified <b>S</b>ince".

Correctly returns header "304 Last Modified" on request "If-Modified-Since" from a web browser or search engine spider (Google, Yahoo, Yandex, etc.)