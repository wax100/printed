<?php
class modLMIMS extends xPDOObject {}