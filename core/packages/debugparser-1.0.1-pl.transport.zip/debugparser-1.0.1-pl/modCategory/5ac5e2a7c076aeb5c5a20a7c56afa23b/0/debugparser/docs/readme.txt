--------------------
debugParser
--------------------
Author: Vasiliy Naumkin <bezumkin@yandex.ru>
--------------------

Component for display verbose information about processing tags in modParser of MODX Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/bezumkin/debugParser/issues