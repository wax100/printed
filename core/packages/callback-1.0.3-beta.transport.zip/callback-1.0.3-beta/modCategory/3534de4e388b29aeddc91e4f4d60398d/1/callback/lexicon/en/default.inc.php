<?php
$_lang['callback'] = 'yMaps TV-input';