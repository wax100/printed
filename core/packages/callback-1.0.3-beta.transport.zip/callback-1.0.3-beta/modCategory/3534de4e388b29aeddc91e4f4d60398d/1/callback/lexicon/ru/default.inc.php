<?php
$_lang['setting_callback.login'] = 'Логин в SMSC.ru';
$_lang['setting_callback.password'] = 'Пароль в SMSC.ru';
$_lang['setting_callback.phone'] = 'Телефон, куда отправляются СМС';