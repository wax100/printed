<?php

$_lang['area_autoredirector_main'] = 'Main';

$_lang['setting_autoredirector_some_setting'] = 'Some setting';
$_lang['setting_autoredirector_some_setting_desc'] = 'This is description for some setting';