<?php
require_once (dirname(dirname(__FILE__)) . '/arrule.class.php');
class arRule_mysql extends arRule {}