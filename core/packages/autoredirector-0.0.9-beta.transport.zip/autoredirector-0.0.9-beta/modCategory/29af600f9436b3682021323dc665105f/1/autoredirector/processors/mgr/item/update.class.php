<?php
/**
 * Update an Item
 */
class autoRedirectorItemUpdateProcessor extends modObjectUpdateProcessor {
	public $objectType = 'arRule';
	public $classKey = 'arRule';
	public $languageTopics = array('autoredirector');
}

return 'autoRedirectorItemUpdateProcessor';
