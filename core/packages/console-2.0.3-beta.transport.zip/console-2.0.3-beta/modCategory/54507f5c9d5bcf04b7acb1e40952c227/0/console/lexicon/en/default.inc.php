<?php

$_lang['console'] = 'Console';
$_lang['console_desc'] = 'Console for execution php-code';
$_lang['console_tab'] = 'PHP Codeeditor';
$_lang['console_exec'] = 'Execute';
$_lang['console_formated_result'] = 'Formated result';
$_lang['console_source_result'] = 'Source result';
