<?php
$_lang['ymaps'] = 'yMaps TV-карта';