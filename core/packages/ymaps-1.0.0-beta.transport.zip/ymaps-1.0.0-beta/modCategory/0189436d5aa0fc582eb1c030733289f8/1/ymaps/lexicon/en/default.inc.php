<?php
$_lang['ymaps'] = 'yMaps TV-input';