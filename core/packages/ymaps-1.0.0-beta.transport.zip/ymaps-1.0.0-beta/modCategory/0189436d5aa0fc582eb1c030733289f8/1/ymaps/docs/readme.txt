--------------------
ymaps
--------------------
Author:  Yana Vostryakova<wax100@gmail.com>
--------------------

Simple Yandex map TV input coordinates
