tinyMCE.addI18n({ml:{
common:{
edit_confirm:"\u0D08 \u0D0E\u0D34\u0D41\u0D24\u0D4D\u0D24\u0D3F\u0D1F\u0D02 \u0D15\u0D3E\u0D23\u0D41\u0D02\u0D35\u0D3F\u0D27\u0D02 \u0D0E\u0D34\u0D41\u0D24\u0D41\u0D28\u0D4D\u0D28\u0D24\u0D3E\u0D15\u0D4D\u0D15\u0D23\u0D4B ?",
apply:"\u0D2A\u0D4D\u0D30\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15",
insert:"\u0D24\u0D3F\u0D30\u0D41\u0D15\u0D41\u0D15",
update:"\u0D2E\u0D3E\u0D31\u0D4D\u0D31\u0D02 \u0D35\u0D30\u0D41\u0D24\u0D4D\u0D24\u0D41\u0D15",
cancel:"\u0D35\u0D47\u0D23\u0D4D\u0D1F\u0D46\u0D28\u0D4D\u0D28\u0D41\u0D35\u0D46\u0D15\u0D4D\u0D15\u0D15",
close:"\u0D05\u0D1F\u0D15\u0D4D\u0D15\u0D41\u0D15",
browse:"\u0D2E\u0D47\u0D2F\u0D41\u0D15",
class_name:"\u0D24\u0D30\u0D02",
not_set:"-- Not set --",
clipboard_msg:"\u0D2E\u0D41\u0D31\u0D3F\u0D15\u0D4D\u0D15\u0D32\u0D4D\u200D/\u0D2A\u0D15\u0D30\u0D4D\u200D\u0D24\u0D4D\u0D24\u0D32\u0D4D\u200D/\u0D12\u0D1F\u0D4D\u0D1F\u0D3F\u0D15\u0D4D\u0D15\u0D32\u0D4D\u200D  \u0D0E\u0D28\u0D4D\u0D28\u0D3F\u0D35 '\u0D2E\u0D4B\u0D38\u0D3F\u0D32\u0D4D\u0D32'\u0D2F\u0D3F\u0D32\u0D41\u0D02 '\u0D2B\u0D2F\u0D30\u0D4D\u200D\u0D2B\u0D4B\u0D15\u0D4D\u0D38\u0D4D'\u0D32\u0D41\u0D02 \u0D32\u0D2D\u0D4D\u0D2F\u0D2E\u0D32\u0D4D\u0D32.  \u200C\n\u0D24\u0D3E\u0D19\u0D4D\u0D15\u0D33\u0D4D\u200D\u0D15\u0D4D\u0D15\u0D41 \u0D07\u0D24\u0D3F\u0D28\u0D46 \u0D15\u0D41\u0D31\u0D3F\u0D1A\u0D4D\u0D1A\u0D41\u0D4D \u0D15\u0D42\u0D1F\u0D41\u0D24\u0D32\u0D4D\u200D \u0D05\u0D31\u0D3F\u0D2F\u0D23\u0D4B ?",
clipboard_no_support:"Currently not supported by your browser, use keyboard shortcuts instead.",
popup_blocked:"Sorry, but we have noticed that your popup-blocker has disabled a window that provides application functionality. You will need to disable popup blocking on this site in order to fully utilize this tool.",
invalid_data:"\u0D2A\u0D3F\u0D34\u0D35\u0D41\u0D4D: Invalid values entered, these are marked in red.",
more_colors:"\u0D15\u0D42\u0D1F\u0D41\u0D24\u0D32\u0D4D\u200D \u0D28\u0D3F\u0D31\u0D19\u0D4D\u0D19\u0D33\u0D4D\u200D"
},
contextmenu:{
align:"Alignment",
left:"Left",
center:"Center",
right:"Right",
full:"Full"
},
insertdatetime:{
date_fmt:"%Y-%m-%d",
time_fmt:"%H:%M:%S",
insertdate_desc:"Insert date",
inserttime_desc:"Insert time",
months_long:"\u0D1C\u0D28\u0D41\u0D35\u0D30\u0D3F, \u0D2B\u0D46\u0D2C\u0D4D\u0D30\u0D41\u0D35\u0D30\u0D3F, \u0D2E\u0D3E\u0D30\u0D4D\u200D\u0D1A\u0D4D\u0D1A\u0D41\u0D4D, \u0D0F\u0D2A\u0D4D\u0D30\u0D3F\u0D32\u0D4D\u200D, \u0D2E\u0D46\u0D2F\u0D4D, \u0D1C\u0D41\u0D23\u0D4D\u200D, \u0D1C\u0D42\u0D32\u0D3E\u0D2F\u0D4D, \u0D06\u0D17\u0D38\u0D4D\u0D24\u0D4D, \u0D38\u0D46\u0D2A\u0D4D\u0D24\u0D02\u0D2C\u0D30\u0D4D\u200D, \u0D12\u0D15\u0D4D\u0D1F\u0D4B\u0D2C\u0D30\u0D4D\u200D, \u0D28\u0D35\u0D02\u0D2C\u0D30\u0D4D\u200D, \u0D21\u0D3F\u0D38\u0D02\u0D2C\u0D30\u0D4D\u200D",
months_short:"\u0D1C\u0D28\u0D41, \u0D2B\u0D46\u0D2C\u0D4D\u0D30\u0D41, \u0D2E\u0D3E\u0D30\u0D4D\u200D, \u0D0F\u0D2A\u0D4D\u0D30\u0D3F, \u0D2E\u0D46, \u0D1C\u0D41\u0D23\u0D4D\u200D, \u0D1C\u0D42\u0D32\u0D3E, \u0D06\u0D17, \u0D38\u0D46\u0D2A\u0D4D\u0D24\u0D02, \u0D12\u0D15\u0D4D\u0D1F\u0D4B, \u0D28\u0D35\u0D02, \u0D21\u0D3F\u0D38\u0D02",
day_long:"\u0D1E\u0D3E\u0D2F\u0D30\u0D4D\u200D, \u0D24\u0D3F\u0D19\u0D4D\u0D15\u0D33\u0D4D\u200D, \u0D1A\u0D4A\u0D35\u0D4D\u0D35, \u0D2C\u0D41\u0D27\u0D28\u0D4D\u200D, \u0D35\u0D4D\u0D2F\u0D3E\u0D34\u0D02, \u0D35\u0D46\u0D33\u0D4D\u0D33\u0D3F, \u0D36\u0D28\u0D3F, \u0D1E\u0D3E\u0D2F\u0D30\u0D4D\u200D",
day_short:"\u0D1E\u0D3E, \u0D24\u0D3F, \u0D1A\u0D4A, \u0D2C\u0D41, \u0D35\u0D4D\u0D2F\u0D3E, \u0D35\u0D46, \u0D36, \u0D1E\u0D3E"
},
print:{
print_desc:"Print"
},
preview:{
preview_desc:"Preview"
},
directionality:{
ltr_desc:"Direction left to right",
rtl_desc:"Direction right to left"
},
layer:{
insertlayer_desc:"Insert new layer",
forward_desc:"Move forward",
backward_desc:"Move backward",
absolute_desc:"Toggle absolute positioning",
content:"New layer..."
},
save:{
save_desc:"Save",
cancel_desc:"Cancel all changes"
},
nonbreaking:{
nonbreaking_desc:"Insert non-breaking space character"
},
iespell:{
iespell_desc:"Run spell checking",
download:"ieSpell not detected. Do you want to install it now?"
},
advhr:{
advhr_desc:"Horizontal rule"
},
emotions:{
emotions_desc:"Emotions"
},
searchreplace:{
search_desc:"Find",
replace_desc:"Find/Replace"
},
advimage:{
image_desc:"Insert/edit image"
},
advlink:{
link_desc:"Insert/edit link"
},
xhtmlxtras:{
cite_desc:"Citation",
abbr_desc:"Abbreviation",
acronym_desc:"Acronym",
del_desc:"Deletion",
ins_desc:"Insertion",
attribs_desc:"Insert/Edit Attributes"
},
style:{
desc:"Edit CSS Style"
},
paste:{
paste_text_desc:"Paste as Plain Text",
paste_word_desc:"Paste from Word",
selectall_desc:"Select All",
plaintext_mode_sticky:"Paste is now in plain text mode. Click again to toggle back to regular paste mode. After you paste something you will be returned to regular paste mode.",
plaintext_mode:"Paste is now in plain text mode. Click again to toggle back to regular paste mode."
},
paste_dlg:{
text_title:"Use CTRL+V on your keyboard to paste the text into the window.",
text_linebreaks:"Keep linebreaks",
word_title:"Use CTRL+V on your keyboard to paste the text into the window."
},
table:{
desc:"Inserts a new table",
row_before_desc:"Insert row before",
row_after_desc:"Insert row after",
delete_row_desc:"Delete row",
col_before_desc:"Insert column before",
col_after_desc:"Insert column after",
delete_col_desc:"Remove column",
split_cells_desc:"Split merged table cells",
merge_cells_desc:"Merge table cells",
row_desc:"Table row properties",
cell_desc:"Table cell properties",
props_desc:"Table properties",
paste_row_before_desc:"Paste table row before",
paste_row_after_desc:"Paste table row after",
cut_row_desc:"Cut table row",
copy_row_desc:"Copy table row",
del:"Delete table",
row:"Row",
col:"Column",
cell:"Cell"
},
autosave:{
unload_msg:"The changes you made will be lost if you navigate away from this page.",
restore_content:"Restore auto-saved content.",
warning_message:"If you restore the saved content, you will lose all the content that is currently in the editor.\n\nAre you sure you want to restore the saved content?."
},
fullscreen:{
desc:"Toggle fullscreen mode"
},
media:{
desc:"Insert / edit embedded media",
edit:"Edit embedded media"
},
fullpage:{
desc:"Document properties"
},
template:{
desc:"Insert predefined template content"
},
visualchars:{
desc:"\u0D26\u0D43\u0D36\u0D4D\u0D2F \u0D28\u0D3F\u0D2F\u0D28\u0D4D\u0D24\u0D4D\u0D30\u0D23 \u0D05\u0D15\u0D4D\u0D37\u0D30\u0D19\u0D4D\u0D19\u0D33\u0D4D\u200D \u0D2E\u0D3E\u0D31\u0D4D\u0D31\u0D41\u0D15."
},
spellchecker:{
desc:"\u0D05\u0D15\u0D4D\u0D37\u0D30\u0D2A\u0D30\u0D3F\u0D36\u0D4B\u0D27\u0D28 \u0D28\u0D3F\u0D2F\u0D28\u0D4D\u0D24\u0D4D\u0D30\u0D23\u0D02",
menu:"\u0D05\u0D15\u0D4D\u0D37\u0D30\u0D2A\u0D30\u0D3F\u0D36\u0D4B\u0D27\u0D28\u0D3E \u0D15\u0D4D\u0D30\u0D2E\u0D40\u0D15\u0D30\u0D23\u0D19\u0D4D\u0D19\u0D33\u0D4D\u200D",
ignore_word:"\u0D35\u0D3E\u0D15\u0D4D\u0D15\u0D41\u0D4D \u0D05\u0D35\u0D17\u0D23\u0D3F\u0D15\u0D4D\u0D15\u0D42",
ignore_words:"\u0D0E\u0D32\u0D4D\u0D32\u0D3E\u0D02 \u0D05\u0D35\u0D17\u0D23\u0D3F\u0D15\u0D4D\u0D15\u0D42",
langs:"\u0D2D\u0D3E\u0D37\u0D15\u0D33\u0D4D\u200D",
wait:"\u0D26\u0D2F\u0D35\u0D3E\u0D2F\u0D3F \u0D15\u0D3E\u0D24\u0D4D\u0D24\u0D41\u0D28\u0D3F\u0D32\u0D4D\u0D15\u0D41...",
sug:"\u0D05\u0D2D\u0D3F\u0D2A\u0D4D\u0D30\u0D3E\u0D2F\u0D19\u0D4D\u0D19\u0D33\u0D4D\u200D",
no_sug:"\u0D05\u0D2D\u0D3F\u0D2A\u0D4D\u0D30\u0D3E\u0D2F\u0D2E\u0D3F\u0D32\u0D4D\u0D32",
no_mpell:"\u0D05\u0D15\u0D4D\u0D37\u0D30\u0D24\u0D4D\u0D24\u0D46\u0D31\u0D4D\u0D31\u0D3F\u0D32\u0D4D\u0D32."
},
pagebreak:{
desc:"\u0D2A\u0D47\u0D1C\u0D41\u0D4D \u0D24\u0D3F\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15"
},
advlist:{
types:"Types",
def:"Default",
lower_alpha:"Lower alpha",
lower_greek:"Lower greek",
lower_roman:"Lower roman",
upper_alpha:"Upper alpha",
upper_roman:"Upper roman",
circle:"Circle",
disc:"Disc",
square:"Square"
}}});