tinyMCE.addI18n({bn:{
common:{
edit_confirm:"\u0986\u09AA\u09A8\u09BF \u0995\u09BF \u098F\u0987 textarea\u099F\u09BF\u09B0 \u099C\u09A8\u09CD\u09AF WYSIWYG \u09AE\u09CB\u09A1 \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09A4\u09C7 \u099A\u09BE\u09A8?",
apply:"\u098F\u09AA\u09CD\u09B2\u09CD\u09AF\u09BE\u0987",
insert:"\u0987\u09A8\u09B8\u09BE\u09B0\u09CD\u099F",
update:"\u0986\u09AA\u09A1\u09C7\u099F",
cancel:"\u0995\u09CD\u09AF\u09BE\u09A8\u09B8\u09C7\u09B2",
close:"\u09AC\u09A8\u09CD\u09A7",
browse:"\u09AC\u09CD\u09B0\u09BE\u0989\u099C",
class_name:"\u0995\u09CD\u09B2\u09BE\u09B8",
not_set:"-- \u09B8\u09C7\u099F \u09A8\u09DF --",
clipboard_msg:"\u0995\u09AA\u09BF/\u0995\u09BE\u099F/\u09AA\u09C7\u09B7\u09CD\u099F \u09AE\u099C\u09BF\u09B2\u09BE \u098F\u09AC\u0982 \u09AB\u09BE\u09DF\u09BE\u09B0\u09AB\u0995\u09CD\u09B8 \u098F \u09B8\u09AE\u09CD\u09AD\u09AC \u09A8\u09DF\n\u0986\u09AA\u09A8\u09BF \u0995\u09BF \u098F\u0987 \u09AC\u09BF\u09B7\u09DF\u099F\u09BF\u09B0 \u09B8\u09AE\u09CD\u09AC\u09A8\u09CD\u09A7\u09C7 \u0986\u09B0\u0993 \u09AC\u09C7\u09B6\u09BF \u09A4\u09A5\u09CD\u09AF \u099A\u09BE\u09A8",
clipboard_no_support:"\u0986\u09AA\u09A8\u09BE\u09B0 \u09AC\u09CD\u09B0\u09BE\u0989\u099C\u09BE\u09B0\u09C7\u09B0 \u09A6\u09CD\u09AC\u09BE\u09B0\u09BE \u09AC\u09B0\u09CD\u09A4\u09AE\u09BE\u09A8\u09C7 \u09B8\u09AE\u09B0\u09CD\u09A5\u09BF\u09A4 \u09A8\u09BE, \u09AA\u09B0\u09BF\u09AC\u09B0\u09CD\u09A4\u09C7 \u0995\u09C0\u09AC\u09CB\u09B0\u09CD\u09A1 \u09B6\u09B0\u09CD\u099F\u0995\u09BE\u099F  \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8\u0964",
popup_blocked:"\u09A6\u09C1\u0983\u0996\u09BF\u09A4, \u0995\u09BF\u09A8\u09CD\u09A4\u09C1 \u0986\u09AE\u09B0\u09BE \u09B2\u0995\u09CD\u09B7\u09CD\u09AF \u0995\u09B0\u09C7\u099B\u09BF \u09AF\u09C7 \u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u09AA-\u0986\u09AA \u09AC\u09CD\u09B2\u0995\u09BE\u09B0 \u098F\u0995\u099F\u09BF \u0989\u0987\u09A8\u09CD\u09A1\u09CB \u09A8\u09BF\u09B7\u09CD\u0995\u09CD\u09B0\u09BF\u09DF \u0995\u09B0\u09C7\u099B\u09C7 \u09AF\u09BE \u0985\u09CD\u09AF\u09BE\u09AA\u09B2\u09BF\u0995\u09C7\u09B6\u09A8 \u098F\u09B0 \u09AB\u09BE\u0982\u09B6\u09A8\u09BE\u09B2\u09BF\u099F\u09BF\u09B0 \u099C\u09A8\u09CD\u09AF \u09AA\u09CD\u09B0\u09DF\u09CB\u099C\u09A8\u09C0\u09DF\u0964\u0986\u09AA\u09A8\u09BF \u098F\u0987 \u099F\u09C1\u09B2\u099F\u09BF \u09B8\u09AE\u09CD\u09AA\u09C2\u09B0\u09CD\u09A3\u09AD\u09BE\u09AC\u09C7 \u09AC\u09CD\u09AF\u09BE\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09A4\u09C7 \u099A\u09BE\u0987\u09B2\u09C7 \u098F\u0987 \u09B8\u09BE\u0987\u099F\u099F\u09BF \u09A5\u09C7\u0995\u09C7 \u09AA\u09AA-\u0986\u09AA \u09AC\u09CD\u09B2\u0995\u09BF\u0982 \u09A8\u09BF\u09B7\u09CD\u0995\u09CD\u09B0\u09BF\u09DF \u0995\u09B0\u09A4\u09C7 \u09B9\u09AC\u09C7\u0964",
invalid_data:"\u09A4\u09CD\u09B0\u09C1\u099F\u09BF: \u09AC\u09C7\u09A0\u09BF\u0995 \u09AE\u09BE\u09A8 \u09A2\u09C1\u0995\u09BE\u09A8\u09CB \u09B9\u09DF\u09C7\u099B\u09C7, \u098F\u0987\u0997\u09C1\u09B2\u09BF \u09B2\u09BE\u09B2 \u099A\u09BF\u09B9\u09CD\u09A8\u09BF\u09A4 \u0995\u09B0\u09BE \u09B9\u09B2\u0964",
more_colors:"\u0986\u09B0\u0993 \u09AC\u09C7\u09B6\u09BF \u09B0\u0982"
},
contextmenu:{
align:"Alignment",
left:"Left",
center:"Center",
right:"Right",
full:"Full"
},
insertdatetime:{
date_fmt:"%Y-%m-%d",
time_fmt:"%H:%M:%S",
insertdate_desc:"Insert date",
inserttime_desc:"Insert time",
months_long:"January,February,March,April,May,June,July,August,September,October,November,December",
months_short:"Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec",
day_long:"Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday",
day_short:"Sun,Mon,Tue,Wed,Thu,Fri,Sat,Sun"
},
print:{
print_desc:"Print"
},
preview:{
preview_desc:"Preview"
},
directionality:{
ltr_desc:"Direction left to right",
rtl_desc:"Direction right to left"
},
layer:{
insertlayer_desc:"Insert new layer",
forward_desc:"Move forward",
backward_desc:"Move backward",
absolute_desc:"Toggle absolute positioning",
content:"New layer..."
},
save:{
save_desc:"Save",
cancel_desc:"Cancel all changes"
},
nonbreaking:{
nonbreaking_desc:"Insert non-breaking space character"
},
iespell:{
iespell_desc:"Run spell checking",
download:"ieSpell not detected. Do you want to install it now?"
},
advhr:{
advhr_desc:"Horizontal rule"
},
emotions:{
emotions_desc:"Emotions"
},
searchreplace:{
search_desc:"Find",
replace_desc:"Find/Replace"
},
advimage:{
image_desc:"Insert/edit image"
},
advlink:{
link_desc:"Insert/edit link"
},
xhtmlxtras:{
cite_desc:"Citation",
abbr_desc:"Abbreviation",
acronym_desc:"Acronym",
del_desc:"Deletion",
ins_desc:"Insertion",
attribs_desc:"Insert/Edit Attributes"
},
style:{
desc:"Edit CSS Style"
},
paste:{
paste_text_desc:"Paste as Plain Text",
paste_word_desc:"Paste from Word",
selectall_desc:"Select All",
plaintext_mode_sticky:"Paste is now in plain text mode. Click again to toggle back to regular paste mode. After you paste something you will be returned to regular paste mode.",
plaintext_mode:"Paste is now in plain text mode. Click again to toggle back to regular paste mode."
},
paste_dlg:{
text_title:"Use CTRL+V on your keyboard to paste the text into the window.",
text_linebreaks:"Keep linebreaks",
word_title:"Use CTRL+V on your keyboard to paste the text into the window."
},
table:{
desc:"Inserts a new table",
row_before_desc:"Insert row before",
row_after_desc:"Insert row after",
delete_row_desc:"Delete row",
col_before_desc:"Insert column before",
col_after_desc:"Insert column after",
delete_col_desc:"Remove column",
split_cells_desc:"Split merged table cells",
merge_cells_desc:"Merge table cells",
row_desc:"Table row properties",
cell_desc:"Table cell properties",
props_desc:"Table properties",
paste_row_before_desc:"Paste table row before",
paste_row_after_desc:"Paste table row after",
cut_row_desc:"Cut table row",
copy_row_desc:"Copy table row",
del:"Delete table",
row:"Row",
col:"Column",
cell:"Cell"
},
autosave:{
unload_msg:"The changes you made will be lost if you navigate away from this page.",
restore_content:"Restore auto-saved content.",
warning_message:"If you restore the saved content, you will lose all the content that is currently in the editor.\n\nAre you sure you want to restore the saved content?."
},
fullscreen:{
desc:"Toggle fullscreen mode"
},
media:{
desc:"Insert / edit embedded media",
edit:"Edit embedded media"
},
fullpage:{
desc:"Document properties"
},
template:{
desc:"Insert predefined template content"
},
visualchars:{
desc:"Visual control characters on/off."
},
spellchecker:{
desc:"Toggle spellchecker",
menu:"Spellchecker settings",
ignore_word:"Ignore word",
ignore_words:"Ignore all",
langs:"Languages",
wait:"Please wait...",
sug:"Suggestions",
no_sug:"No suggestions",
no_mpell:"No misspellings found."
},
pagebreak:{
desc:"Insert page break."
},
advlist:{
types:"Types",
def:"Default",
lower_alpha:"Lower alpha",
lower_greek:"Lower greek",
lower_roman:"Lower roman",
upper_alpha:"Upper alpha",
upper_roman:"Upper roman",
circle:"Circle",
disc:"Disc",
square:"Square"
}}});