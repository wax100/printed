tinyMCE.addI18n('is.modxlink',{
    link_desc:"Insert/edit link"
});