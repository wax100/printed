tinyMCE.addI18n({
	en: {
		typograf: {
			desc:				"Typograf",
			confirm:		"Save changes?",
			title:			"Choose typograf",
			lebedev:		"Lebedev",
			spearance:	"Spearance",
			jare:				"Muravjev"
		}
	}
});