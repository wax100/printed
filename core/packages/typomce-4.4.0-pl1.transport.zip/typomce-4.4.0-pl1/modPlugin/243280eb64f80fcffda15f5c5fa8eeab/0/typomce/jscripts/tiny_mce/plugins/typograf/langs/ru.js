tinyMCE.addI18n({
	ru:{
		typograf:{
			desc:				"Типограф",
			confirm:		"Применить изменения?",
			title:			"Выберите типограф",
			lebedev:		"Лебедева",
			spearance:	"Spearance",
			jare:				"Муравьева"
		}
	}
});