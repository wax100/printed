<?php

$_lang['ajaxsnippet_prop_snippet'] = 'Snippet, that need to run trough Ajax.';
$_lang['ajaxsnippet_prop_propertySet'] = 'If you want to use property set of snippet - specify it`s name.';
$_lang['ajaxsnippet_prop_wrapper'] = 'Wrapper chunk. It must contain element with id="[[+key]]".';
$_lang['ajaxsnippet_prop_as_mode'] = 'How to run snippet: right after page loads, or by click on special trigger link?';
$_lang['ajaxsnippet_prop_as_trigger'] = 'Text for trigger link for "OnClick" mode. By default is lexicon entry "as_trigger".';
$_lang['ajaxsnippet_prop_as_target'] = 'CSS selector of element into which will be pasted the response from the server. By default, the answer will be inserted into the place of output wrapper.';