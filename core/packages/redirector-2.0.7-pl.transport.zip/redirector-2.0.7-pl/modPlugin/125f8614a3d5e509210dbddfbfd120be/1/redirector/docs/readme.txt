--------------------
3PC: Redirector
--------------------
Version: 1.0
Since: April 21st, 2010
Author: Shaun McCormick <shaun@collabpad.com> and Jason Coward <jason@collabpad.com>

Handles 301 redirects for your site.
