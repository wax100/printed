-------------------------------------------
Plulgin: Inherit Template (for MODX Revolution)
-------------------------------------------
Author: goldsky <goldsky.milis@gmail.com>

This plugin is to make the user ables to set the template for the new child
documents automatically of the edited parent document (container, as MODX's
term) in the back-end manager.

This won't be applied to the editing mode of the child document.
This only works one level, as it's intended.