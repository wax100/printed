<?php

$_lang['setting_inheritTpl.tvname'] = 'TV\'s name for Inherit Template';
$_lang['setting_inheritTpl.tvname_desc'] = 'The name of the Templave Variable';

